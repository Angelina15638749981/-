/**
 * 获取公司列表
 * @returns {*}
 */
function doCompanyList() {
    var url = "/cdk/company/findList";
    var parameter = {};
    var resultData;
    CDK.get(url,"json",false,parameter,function (result) {
         if (result){
             if (result.code == "200"){
                 resultData = result.obj.list;
             }
         } 
    });
    return resultData;
}

/**
 * 根据公司获取授信的票据类型列表
 * @param companyId 公司ID
 */
function doPaperTypeListByCompanyId(companyId) {
    if (!companyId){
        return;
    }
    var url = "/cdk/priceRelation/doPaperTypeList";
    var parameter = {
        "type":0,
        "companyId":companyId
    };
    var resultData;
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                resultData = result.obj.list;
            }
        }
    });
    return resultData;
}

/**
 * 根据公司、票据类型 获取授信的银行类型
 * @param companyId 公司ID
 * @param paperTypeId 公司ID
 * @returns {*}
 */
function doBankTypeList(companyId,paperTypeId) {
    if (!companyId || !paperTypeId){
        return;
    }
    var url = "/cdk/priceRelation/doBankTypeList";
    var parameter = {
        "type":0,
        "companyId":companyId,
        "paperTypeId":paperTypeId
    };
    var resultData;
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                resultData = result.obj.list;
            }
        }
    });
    return resultData;
}

/**
 * 根据 公司 票据类型 银行类型 获取银行列表
 * @param companyId 公司ID
 * @param paperTypeId 公司ID
 * @param bankTypeId 银行类型ID
 */
function doBankList(companyId,paperTypeId,bankTypeId) {
    if (!companyId || !paperTypeId || !bankTypeId){
        return;
    }
    var url = "/cdk/priceRelation/doBankList";
    var parameter = {
        "type":0,
        "companyId":companyId,
        "paperTypeId":paperTypeId,
        "bankTypeId":bankTypeId
    };
    var resultData = {};
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                resultData = result.obj.list;
            }
        }
    });
    return resultData;
}

/**
 * 获得利率类型列表
 * @param companyId 公司ID
 * @param paperTypeId 票据类型ID
 * @param bankTypeId 银行类型ID
 * @param rType 类型状态(1: 半年期：2 ：一年期)
 * @returns {*}
 */
function doRateList(companyId,paperTypeId,bankTypeId,rType) {
    if (!companyId || !paperTypeId || !bankTypeId || !rType){
        return;
    }
    rateData.promptCM = "正在查询...";
    var url = "/cdk/rate/findList";
    var parameter = {
        "companyId.id":companyId,
        "paperTypeId.id":paperTypeId,
        "bankTypeId.id":bankTypeId,
        "rType":rType,
    };
    var resultData;
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                resultData = result.obj.list;
            }
        }
    });
    rateData.promptCM = "查询成功";
    setTimeout(function () {
        rateData.promptCM = "";
    },2000);
    return resultData;
}

/**
 * 获取 行 列 数据
 * @param companyId 公司ID
 * @param paperTypeId 票据类型ID
 * @param bankTypeId 银行类型ID
 * @param rType 类型状态(1: 半年期：2 ：一年期)
 * @param type 0：获取“行”数据  1：获取“列”数据
 * @returns {*}
 */
function doRowList(companyId,paperTypeId,bankTypeId,rType,type) {
    if (!companyId || !paperTypeId || !bankTypeId || !rType){
        return;
    }
    var url = "/cdk/rate/doRateTableRow";
    var parameter = {
        "companyId":companyId,
        "paperTypeId":paperTypeId,
        "bankTypeId":bankTypeId,
        "rType":rType,
        "type":type,
    };
    var resultData;
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                resultData = result.obj;
            }
        }
    });
    return resultData;
}

/**
 * 修改数据
 * @param e
 */
function rateUpdate (e) {
    if (!e){
        return;
    }
    rateData.promptCM = "正在保存...";
    var url = "/cdk/rate/rateUpdate";
    var parameter = $(e).parents("form").serialize();
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code != "200"){
                //修改失败重新加载数据
                rateData.bankTypeListCM = rateData.bankTypeListCM;
            }
        }
    });
    rateData.promptCM = "保存成功";
    setTimeout(function () {
        rateData.promptCM = "";
    },2000);
}

/**
 * 添加数据
 */
function rateAdd(e) {
    var url = "/cdk/rate/save";
    var parameter = $("#rateAdd").serialize();
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                //刷新数据
                rateData.bankTypeListCM = rateData.bankTypeListCM;
            }
        }
    });
    $("#rateAddModal").attr("data-dismiss", "modal");
    $("#rateAdd").find("input").val("");
}

/**
 * 删除数据
 */
function rateDel(id) {
    var url = "/cdk/rate/delete";
    var parameter = {
        id:id,
        type:0
    };
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                //刷新数据
                rateData.bankTypeListCM = rateData.bankTypeListCM;
            }
        }
    });
}

/**
 * 更换查询条件
 * @param e
 * @param type
 */
function changeCondition(e,type) {
    if (!e || !type){
        return;
    }
    var id = $(e).val();
    if (!id){
        return;
    }
    if (type == "0"){
        rateData.companyIdCM = id;
        $("#companyModal").val(id);
    }else if (type == "1"){
        rateData.paperTypeIdCM = id;
        $("#paperTypeModal").val(id);
    }
}

function changeLineDel(e) {
    if (e.checked){
        rateData.minMoneyDel = $(e).attr("data-min");
        rateData.maxMoneyDel = $(e).attr("data-max");
    }else {
        rateData.minMoneyDel = null;
        rateData.maxMoneyDel = null;
    }
}

function changeColDel(e) {
    if (e.checked){
        rateData.sDayDel = $(e).attr("data-min");
        rateData.eDayDel = $(e).attr("data-max");
    }else {
        rateData.sDayDel = null;
        rateData.eDayDel = null;
    }
}

var rateData = new Vue({
    el:"#rateBody",
    data:{
        companyList:{},
        companyId:"",
        paperTypeList:{},
        paperTypeId:"",
        bankTypeList:{},
        rateList:{},

        minMoneyDel:"",
        maxMoneyDel:"",
        sDayDel:"",
        eDayDel:"",

        yRateModal:0,
        mRateModal:0,

        prompt:""
    },
    watch:{
        yRateModal:function (value) {
            if (value){
                this.yRateModal = Number(value);
                this.mRateModal = Number(value / 1.2);
            }else {
                yRateModal = value;
                mRateModal = value;
            }
        },
        mRateModal:function (value) {
            if (value){
                this.yRateModal = Number(value * 1.2) ;
                this.mRateModal = Number(value);
            }else {
                yRateModal = value;
                mRateModal = value;
            }
        }
    },
    computed:{
        companyListCM:{
            get:function () {
                return this.companyList;
            },
            set:function (value) {
                if (value && value.length > 0){
                    this.companyIdCM = value[0].id;
                }
                this.companyList = value;
            }
        },
        companyIdCM:{
            get:function () {
                return this.companyId;
            },
            set:function (value) {
                this.companyId = value;
                this.paperTypeListCM = doPaperTypeListByCompanyId(this.companyId);
            }
        },
        paperTypeListCM:{
            get:function () {
                return this.paperTypeList;
            },
            set:function (value) {
                if (value && value.length > 0){
                    this.paperTypeIdCM = value[0].id;
                }
                this.paperTypeList = value;
            }
        },

        paperTypeIdCM:{
            get:function () {
                return this.paperTypeId;
            },
            set:function (value) {
                this.paperTypeId = value;
                this.bankTypeListCM = doBankTypeList(this.companyId,this.paperTypeId);
            }
        },
        bankTypeListCM:{
            get:function () {
                return this.bankTypeList;
            },
            set:function (value) {
                if (value && value.length > 0){
                    this.rateListCM = null;
                    for (var x in value){
                        var data = {
                            bankTypeId:value[x].id,
                            name : value[x].name,
                            bankList : doBankList(this.companyId,this.paperTypeId,value[x].id),
                            moneyListS:doRowList(this.companyId,this.paperTypeId,value[x].id,"1","0"),
                            daysListS:doRowList(this.companyId,this.paperTypeId,value[x].id,"1","1"),
                            listS : doRateList(this.companyId,this.paperTypeId,value[x].id,"1"),
                            moneyListY:doRowList(this.companyId,this.paperTypeId,value[x].id,"2","0"),
                            daysListY:doRowList(this.companyId,this.paperTypeId,value[x].id,"2","1"),
                            listY : doRateList(this.companyId,this.paperTypeId,value[x].id,"2")
                        };
                        this.contentListPush(data);
                    }
                }
                this.bankTypeList = value;
            }
        },
        rateListCM:{
            get:function () {
                console.log(this.rateList);
                return this.rateList;
            },
            set:function (value) {
                this.rateList = value;
            }
        },
        promptCM:{
            get:function () {
                return this.prompt;
            },
            set:function (value) {
                this.prompt = value;
            }
        }
    },
    methods:{
        contentListPush:function (value) {
            if (this.rateList && this.rateList.length){
                this.rateList.push(value);
            }else {
                var list = new Array();
                list.push(value);
                this.rateList = list;
            }
        },
        changeModalValue:function (bankTypeId,rType) {
            $("#bankTypeModal").val(bankTypeId);
            $("#rTypeModal").val(rType);
        },
        deleteRateS:function (bankTypeId) {
            console.log(this.companyId,this.paperTypeId,bankTypeId,this.minMoneyDel,this.maxMoneyDel,this.sDayDel,this.eDayDel);
            for (var x in this.rateList){
                if (this.rateList[x].bankTypeId == bankTypeId){
                    var list = this.rateList[x].listS;
                    if (this.sDayDel && this.eDayDel && this.minMoneyDel && this.maxMoneyDel){
                        for (var i in list){
                            if (list[i].sDay == this.sDayDel
                                && list[i].eDay == this.eDayDel
                                && list[i].minMoney == this.minMoneyDel
                                && list[i].maxMoney == this.maxMoneyDel){
                                rateDel(list[i].id);
                            }
                        }
                    } else {
                        if (this.sDayDel && this.eDayDel){
                            for (var i in list){
                                if (list[i].sDay == this.sDayDel
                                    && list[i].eDay == this.eDayDel){
                                    rateDel(list[i].id);
                                }
                            }
                        }else if (this.minMoneyDel && this.maxMoneyDel) {
                            if (list[i].minMoney == this.minMoneyDel
                                && list[i].maxMoney == this.maxMoneyDel){
                                rateDel(list[i].id);
                            }
                        }
                    }

                }
            }
            this.sDayDel = null;
            this.eDayDel = null;
            this.minMoneyDel = null;
            this.maxMoneyDel = null;
        },
        deleteRateY:function (bankTypeId) {
            console.log(this.companyId,this.paperTypeId,bankTypeId,this.minMoneyDel,this.maxMoneyDel,this.sDayDel,this.eDayDel);
            for (var x in this.rateList){
                if (this.rateList[x].bankTypeId == bankTypeId){
                    var list = this.rateList[x].listY;
                    if (this.sDayDel && this.eDayDel && this.minMoneyDel && this.maxMoneyDel){
                        for (var i in list){
                            if (list[i].sDay == this.sDayDel
                                && list[i].eDay == this.eDayDel
                                && list[i].minMoney == this.minMoneyDel
                                && list[i].maxMoney == this.maxMoneyDel){
                                rateDel(list[i].id);
                            }
                        }
                    } else {
                        if (this.sDayDel && this.eDayDel){
                            for (var i in list){
                                if (list[i].sDay == this.sDayDel
                                    && list[i].eDay == this.eDayDel){
                                    rateDel(list[i].id);
                                }
                            }
                        }else if (this.minMoneyDel && this.maxMoneyDel) {
                            if (list[i].minMoney == this.minMoneyDel
                                && list[i].maxMoney == this.maxMoneyDel){
                                rateDel(list[i].id);
                            }
                        }
                    }
                }
            }
            this.sDayDel = null;
            this.eDayDel = null;
            this.minMoneyDel = null;
            this.maxMoneyDel = null;
        }
    }
});
rateData.companyListCM = doCompanyList();