/**
 * 获取公司列表
 * @param pageNum
 * @param pageSize
 */
function doCompanyList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/company/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj.list;
            }
        }
    });
    return dara;
}

/**
 *  获取票据类型列表
 * @param pageNum
 * @param pageSize
 */
function doPaperTypeList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/paperType/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj.list;
            }
        }
    });
    return dara;
}

/**
 * 获取银行类型列表
 * @param pageNum
 * @param pageSize
 */
function doBankTypeList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/bankType/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj.list;
            }
        }
    });
    return dara;
}

/**
 * 获取银行列表
 * @param pageNum
 * @param pageSize
 */
function doBankList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/bank/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj.list;
            }
        }
    });
    return dara;
}

/**
 * 获取授信的票据类型列表
 * @param pageNum
 * @param pageSize
 * @param companyId
 * @param type
 */
function doCreditPaperTypeList(pageNum,pageSize,companyId,type) {
    var data = null;
    var url = "/cdk/priceRelation/doPaperTypeList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize,
        companyId:companyId,
        type:type
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                data = result.obj.list;
            }
        }
    });
    return data;
}

/**
 * 获取授信的银行类型列表
 * @param pageNum
 * @param pageSize
 * @param companyId
 * @param paperTypeId
 * @param type
 */
function doCreditBankTypeList(pageNum,pageSize,companyId,paperTypeId,type) {
    console.log(pageNum,pageSize,companyId,paperTypeId,type);
    var data = null;
    var url = "/cdk/priceRelation/doBankTypeList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize,
        companyId:companyId,
        paperTypeId:paperTypeId,
        type:type
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                data = result.obj;
            }
        }
    });
    console.log(data);
    return data;
}

/**
 * 获取授信的银行列表
 * @param pageNum
 * @param pageSize
 * @param companyId
 * @param paperTypeId
 * @param bankTypeId
 * @param type
 */
function doCreditBankList(pageNum,pageSize,companyId,paperTypeId,bankTypeId,type) {
    var data = null;
    var url = "/cdk/priceRelation/doBankList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize,
        companyId:companyId,
        paperTypeId:paperTypeId,
        bankTypeId:bankTypeId,
        type:type
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                data = result.obj;
            }
        }
    });
    return data;
}

/**
 * 添加授信
 */
function creditAdd (companyId,paperTypeId,bankTypeId,bankId,type,relationGrade) {
    console.log(companyId,paperTypeId,bankTypeId,bankId,type,relationGrade);
    var url = "/cdk/priceRelation/save";
    var parameter = {
        "companyId.id":companyId,
        "paperTypeId.id":paperTypeId,
        "bankTypeId.id":bankTypeId,
        "bankId.id":bankId,
        "type":type,
        "relationGrade":relationGrade
    };
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                if (type == 0){
                    //刷新数据
                    rateCredit.paperTypeIdCM = rateCredit.paperTypeIdCM;
                } else {
                    //刷新数据
                    paymentCredit.paperTypeIdCM = paymentCredit.paperTypeIdCM;
                }
            }
        }
    });
}

/**
 * 删除授信
 */
function creditDel(companyId,paperTypeId,bankTypeId,bankId,type,relationGrade) {
    console.log(companyId,paperTypeId,bankTypeId,bankId,type,relationGrade);
    var url = "/cdk/priceRelation/deleteByEntity";
    var parameter = {
        "companyId.id":companyId,
        "paperTypeId.id":paperTypeId,
        "bankTypeId.id":bankTypeId,
        "bankId.id":bankId,
        "type":type,
        "relationGrade":relationGrade
    };
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                if (type == 0){
                    //刷新数据
                    rateCredit.paperTypeIdCM = rateCredit.paperTypeIdCM;
                } else {
                    //刷新数据
                    paymentCredit.paperTypeIdCM = paymentCredit.paperTypeIdCM;
                }
            }
        }
    });
}

function pitchUpCompany (e,type) {
    if (e){
        if (type == 0){
            rateCredit.companyIdCM = e.value;
        } else {
            paymentCredit.companyIdCM = e.value;
        }

    }
}

function pitchUpPaperType(e,type) {
    if (e){
        if (type == 0){
            rateCredit.paperTypeIdCM = e.value;
        } else {
            paymentCredit.paperTypeIdCM = e.value;
        }

    }
}

function pitchUpBankType(e) {
    if (e){
        creditEdit.bankTypeId = e.value;
    }
}

function pitchUpBank(e) {
    if (e){
        creditEdit.bankId = e.value;
    }
}


var rateCredit = new Vue({
    el:"#template1",
    data:{
        companyList:{},     //公司列表
        creditPaperTypeList:{}, //授信的票据类型列表
        creditBankTypeInfo:{},  //授信的银行类型 pageInfo
        creditBankInfo:{},      //授信的银行 pageInfo
        companyId:"",           //当前银行ID
        paperTypeId:"",         //当前票据类型ID
        bankTypeId:"",          //当前银行类型
        type:0                  //授信类型
    },
    computed:{
        companyListCM:{
            get:function () {
                return this.companyList;
            },
            set:function (value) {
                this.companyList = value;
                if (value && value.length > 0){
                    this.companyIdCM = value[0].id;
                }else {
                    this.companyIdCM = null;
                }
            }
        },

        creditPaperTypeListCM:{
            get:function () {
                return this.creditPaperTypeList;
            },
            set:function (value) {
                this.creditPaperTypeList = value;
                if (value && value.length > 0){
                    this.paperTypeIdCM = value[0].id;
                }else {
                    this.paperTypeIdCM = null;
                }
            }
        },
        creditBankTypeInfoCM:{
            get:function () {
                return this.creditBankTypeInfo;
            },
            set:function (value) {
                this.creditBankTypeInfo = value;
                if (value){
                    //分页初始化
                    PAGEINFO.initialize(1,value.pages,5,function (pageNum) {
                        //递归获取分页数据
                        this.creditBankTypeInfoCM = doCreditBankTypeList(pageNum,10,rateCredit.companyId,rateCredit.paperTypeId,rateCredit.type);
                    },"rateBankTypePage");
                    if (value.list && value.list.length > 0){
                        this.bankTypeIdCM = value.list[0].id;
                    }else {
                        this.bankTypeIdCM = null;
                    }
                }else {
                    this.bankTypeIdCM = null;
                    $("#rateBankTypePage").html("");
                }

            }
        },
        creditBankInfoCM:{
            get:function () {
                return this.creditBankInfo;
            },
            set:function (value) {
                this.creditBankInfo = value;
                if (value){
                    //分页初始化
                    PAGEINFO.initialize(1,value.pages,5,function (pageNum) {
                        //递归获取分页数据
                        this.creditBankInfoCM = doCreditBankList(pageNum,10,rateCredit.companyId,rateCredit.paperTypeId,rateCredit.bankTypeId);
                    },"rateBankPage");
                }else {
                    $("#rateBankPage").html("");
                }
            }
        },
        companyIdCM:{
            get:function () {
                return this.companyId;
            },
            set:function (value) {
                this.companyId = value;
                this.creditPaperTypeListCM = doCreditPaperTypeList(1,100,value,this.type);
            }
        },
        paperTypeIdCM:{
            get:function () {
                return this.paperTypeId;
            },
            set:function (value) {
                this.paperTypeId = value;
                this.creditBankTypeInfoCM = doCreditBankTypeList(1,10,this.companyId,value,this.type);
            }
        },
        bankTypeIdCM:{
            get:function () {
                return this.bankTypeId;
            },
            set:function (value) {
                this.bankTypeId = value;
                this.creditBankInfoCM = doCreditBankList(1,10,this.companyId,this.paperTypeId,value,this.type);
            }
        }
    },
    methods:{
        pitchUpBankType:function (id) {
            if (id){
                this.bankTypeIdCM = id;
            }
        },
        delBankType:function(id){
            creditDel(this.companyId,this.paperTypeId,id,null,this.type,2);
        },
        delBank:function(id){
            creditDel(this.companyId,this.paperTypeId,this.bankTypeId,id,this.type,3);
        },
        changeCreditEdit1:function () {
            creditEdit.companyId = this.companyIdCM;
            creditEdit.paperTypeId = this.paperTypeId;
            creditEdit.type = this.type;
            $("#editModal").find("select").val("");
        },
        changeCreditEdit2:function () {
            creditEdit.companyId = this.companyIdCM;
            creditEdit.paperTypeId = this.paperTypeId;
            creditEdit.bankTypeId = this.bankTypeId;
            creditEdit.type = this.type;
            $("#editModal2").find("select").val("");
        },
    }
});
rateCredit.companyListCM = doCompanyList(1,100);

var paymentCredit = new Vue({
    el:"#template2",
    data:{
        companyList:{},     //公司列表
        creditPaperTypeList:{}, //授信的票据类型列表
        creditBankTypeInfo:{},  //授信的银行类型 pageInfo
        creditBankInfo:{},      //授信的银行 pageInfo
        companyId:"",           //当前银行ID
        paperTypeId:"",         //当前票据类型ID
        bankTypeId:"",          //当前银行类型
        type:1                  //授信类型
    },
    computed:{
        companyListCM:{
            get:function () {
                return this.companyList;
            },
            set:function (value) {
                this.companyList = value;
                if (value && value.length > 0){
                    this.companyIdCM = value[0].id;
                }else {
                    this.companyIdCM = null;
                }
            }
        },
        creditPaperTypeListCM:{
            get:function () {
                return this.creditPaperTypeList;
            },
            set:function (value) {
                this.creditPaperTypeList = value;
                if (value && value.length > 0){
                    this.paperTypeIdCM = value[0].id;
                }else {
                    this.paperTypeIdCM = null;
                }
            }
        },
        creditBankTypeInfoCM:{
            get:function () {
                return this.creditBankTypeInfo;
            },
            set:function (value) {
                this.creditBankTypeInfo = value;
                if (value){
                    //分页初始化
                    PAGEINFO.initialize(1,value.pages,5,function (pageNum) {
                        //递归获取分页数据
                        this.creditBankTypeInfoCM = doCreditBankTypeList(pageNum,10,rateCredit.companyId,rateCredit.paperTypeId,rateCredit.type);
                    },"paymentBankTypePage");
                    if (value.list && value.list.length > 0){
                        this.bankTypeIdCM = value.list[0].id;
                    }else {
                        this.bankTypeIdCM = null;
                    }
                }else {
                    $("#paymentBankTypePage").html("");
                    this.bankTypeIdCM = null;
                }

            }
        },
        creditBankInfoCM:{
            get:function () {
                return this.creditBankInfo;
            },
            set:function (value) {
                this.creditBankInfo = value;
                if (value){
                    //分页初始化
                    PAGEINFO.initialize(1,value.pages,5,function (pageNum) {
                        //递归获取分页数据
                        this.creditBankInfoCM = doCreditBankList(pageNum,10,rateCredit.companyId,rateCredit.paperTypeId,rateCredit.bankTypeId);
                    },"paymentBankPage");
                }else {
                    $("#paymentBankPage").html("");
                }
            }
        },
        companyIdCM:{
            get:function () {
                return this.companyId;
            },
            set:function (value) {
                this.companyId = value;
                this.creditPaperTypeListCM = doCreditPaperTypeList(1,100,value,this.type);
            }
        },
        paperTypeIdCM:{
            get:function () {
                return this.paperTypeId;
            },
            set:function (value) {
                this.paperTypeId = value;
                this.creditBankTypeInfoCM = doCreditBankTypeList(1,10,this.companyId,value,this.type);
            }
        },
        bankTypeIdCM:{
            get:function () {
                return this.bankTypeId;
            },
            set:function (value) {
                this.bankTypeId = value;
                this.creditBankInfoCM = doCreditBankList(1,10,this.companyId,this.paperTypeId,value,this.type);
            }
        }
    },
    methods:{
        pitchUpBankType:function (id) {
            if (id){
                this.bankTypeIdCM = id;
            }
        },
        delBankType:function(id){
            creditDel(this.companyId,this.paperTypeId,id,null,this.type,2);
        },
        delBank:function(id){
            creditDel(this.companyId,this.paperTypeId,this.bankTypeId,id,this.type,3);
        },
        changeCreditEdit1:function () {
            creditEdit.companyId = this.companyIdCM;
            creditEdit.paperTypeId = this.paperTypeId;
            creditEdit.type = this.type;
            $("#editModal").find("select").val("");
        },
        changeCreditEdit2:function () {
            creditEdit.companyId = this.companyIdCM;
            creditEdit.paperTypeId = this.paperTypeId;
            creditEdit.bankTypeId = this.bankTypeId;
            creditEdit.type = this.type;
            $("#editModal2").find("select").val("");
        },
    }
});
paymentCredit.companyListCM = doCompanyList(1,100);

var creditEdit = new Vue({
    el:"#creditModal",
    data:{
        bankTypeList:{},
        bankList:{},
        companyId:"",
        paperTypeId:"",
        bankTypeId:"",
        bankId:"",
        type:"",
        relationGrade: 2
    },
    mounted(){
        this.bankTypeList = doBankTypeList(1,100);
        this.bankList = doBankList(1,100);
    },
    methods:{
        bankTypeAdd:function () {
            creditAdd(this.companyId,this.paperTypeId,this.bankTypeId,null,this.type,2);
            $("#saveBtn").attr("data-dismiss","modal");
        },
        bankAdd:function () {
            creditAdd(this.companyId,this.paperTypeId,this.bankTypeId,this.bankId,this.type,3);
            $("#saveBtn1").attr("data-dismiss","modal");
        }
    }
});
