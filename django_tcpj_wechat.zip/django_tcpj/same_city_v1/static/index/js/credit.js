var pageSize = 10;
/**
 * 获取公司列表
 * @param pageNum
 * @param pageSize
 * @returns {*}
 */
function doCompanyList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/company/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj;
            }
        } 
    });
    return dara;
}

/**
 *  获取票据类型列表
 * @param pageNum
 * @param pageSize
 * @returns {*}
 */
function doPaperTypeList(pageNum,pageSize) {
    var dara = null;
    var url = "/cdk/paperType/findList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                dara = result.obj.list;
            }
        }
    });
    return dara;
}

/**
 * 获取授信票据类型列表
 * @param pageNum
 * @param pageSize
 * @param companyId
 * @param type 授信类型 0 利率 1 货款
 * @returns {*}
 */
function doCompanyPaperTypeList(pageNum,pageSize,companyId,type) {
    var data = null;
    var url = "/cdk/priceRelation/doPaperTypeList";
    var parameter = {
        pageNum:pageNum,
        pageSize:pageSize,
        companyId:companyId,
        type:type
    };
    CDK.get(url,"json",false,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                data = result.obj;
            }
        } 
    });
    return data;
}

/**
 * 添加授信
 * @param companyId
 * @param paperTypeId
 * @param type
 * @param relationGrade
 */
function creditAdd(companyId,paperTypeId,type,relationGrade) {
    console.log(companyId,paperTypeId,type,relationGrade);
    var url = "/cdk/priceRelation/save";
    var parameter = {
        "companyId.id":companyId,
        "paperTypeId.id":paperTypeId,
        "type":type,
        "relationGrade":relationGrade,
    };
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                if (type == 0){
                    //刷新数据
                    rateCredit.companyIdCM = rateCredit.companyIdCM;
                } else {
                    //刷新数据
                    paymentCredit.companyIdCM = paymentCredit.companyIdCM;
                }
            }
        }
    });
}
/**
 * 删除授信
 * @param companyId
 * @param paperTypeId
 * @param type
 * @param relationGrade
 */
function creditDel(companyId,paperTypeId,type,relationGrade) {
    var url = "/cdk/priceRelation/deleteByEntity";
    var parameter = {
        "companyId.id":companyId,
        "paperTypeId.id":paperTypeId,
        "type":type,
        "relationGrade":relationGrade,
    };
    CDK.get(url,"json",true,parameter,function (result) {
        if (result){
            if (result.code == "200"){
                if (type == 0){
                    //刷新数据
                    rateCredit.companyIdCM = rateCredit.companyIdCM;
                } else {
                    //刷新数据
                    paymentCredit.companyIdCM = paymentCredit.companyIdCM;
                }
            }
        }
    });
}

var rateCredit = new Vue({
    el:"#rate",
    data:{
        companyPageInfo:{},
        companyPageNum:1,
        companyList:{},
        companyId:{},

        paperTypePageInfo:{},
        paperTypePageNum:1,
        paperTypeList:{},

    },
    computed:{
        companyPageInfoCM: {
            get:function () {
                return this.companyPageInfo;
            },
            set:function (value) {
                if (value){
                    this.companyListCM = value.list;
                }
                this.companyPageInfo = value;
            }
        },
        companyListCM:{
            get:function () {
                return this.companyList;
            },
            set:function (value) {
                this.companyList = value;
                if (value && value.length > 0){
                    this.companyIdCM = value[0].id;
                }
            }
        },
        companyIdCM:{
            get:function () {
                return this.companyId;
            },
            set:function (value) {
                this.companyId = value;
                this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,value,0);
            }
        },
        paperTypePageInfoCM:{
            get:function () {
                return this.paperTypePageInfo;
            },
            set:function (value) {
                this.paperTypePageInfo = value;
                if (value){
                    this.paperTypeListCM = value.list;
                }else {
                    this.paperTypeListCM = null;
                }
            }
        },
        paperTypeListCM:{
            get:function () {
                return this.paperTypeList;
            },
            set:function (value) {
                this.paperTypeList = value;
            }
        }
    },
    methods:{
        pitchOn:function (id) {
            if (id){
                this.companyIdCM = id;
            }
        },
        openAdd:function () {
            creditEdit.companyId = this.companyId;
            creditEdit.type = 0;
        },
        deleteCredit:function (paperTypeId) {
            creditDel(this.companyIdCM,paperTypeId,0,1);
        },

        companyPreviousPage:function () {
            if ((this.companyPageNum - 1) < 1){
                return;
            }
            this.companyPageNum--;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },
        companyPage:function (page) {
            if (!page){
                return;
            }
            this.companyPageNum = page;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },
        companyNextPage:function () {
            this.companyPageNum++;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },

        paperTypePreviousPage:function () {
            if ((this.paperTypePageNum - 1) < 1){
                return;
            }
            this.paperTypePageNum--;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,0);
        },
        paperTypePage:function (page) {
            if (!page){
                return;
            }
            this.paperTypePageNum = page;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,0);
        },
        paperTypeNextPage:function () {
            this.paperTypePageNum++;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,0);
        }

    }
});

var paymentCredit = new Vue({
    el:"#payment",
    data:{
        companyPageInfo:{},
        companyPageNum:1,
        companyList:{},
        companyId:{},

        paperTypePageInfo:{},
        paperTypePageNum:1,
        paperTypeList:{},

    },
    computed:{
        companyPageInfoCM: {
            get:function () {
                return this.companyPageInfo;
            },
            set:function (value) {
                this.companyPageInfo = value;
                if (value){
                    this.companyListCM = value.list;
                }
            }
        },
        companyListCM:{
            get:function () {
                return this.companyList;
            },
            set:function (value) {
                this.companyList = value;
                if (value && value.length > 0){
                    this.companyIdCM = value[0].id;
                }
            }
        },
        companyIdCM:{
            get:function () {
                return this.companyId;
            },
            set:function (value) {
                this.companyId = value;
                this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,value,1);
            }
        },
        paperTypePageInfoCM:{
            get:function () {
                return this.paperTypePageInfo;
            },
            set:function (value) {
                this.paperTypePageInfo = value;
                if (value){
                    this.paperTypeListCM = value.list;
                }else {
                    this.paperTypeListCM = null;
                }

            }
        },
        paperTypeListCM:{
            get:function () {
                return this.paperTypeList;
            },
            set:function (value) {
                this.paperTypeList = value;
            }
        }
    },
    methods:{
        pitchOn:function (id) {
            if (id){
                this.companyIdCM = id;
            }
        },
        openAdd:function () {
            creditEdit.companyId = this.companyId;
            creditEdit.type = 1;
        },
        deleteCredit:function (paperTypeId) {
            creditDel(this.companyIdCM,paperTypeId,1,1);
        },

        companyPreviousPage:function () {
            if ((this.companyPageNum - 1) < 1){
                return;
            }
            this.companyPageNum--;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },
        companyPage:function (page) {
            if (!page){
                return;
            }
            this.companyPageNum = page;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },
        companyNextPage:function () {
            this.companyPageNum++;
            this.companyPageInfoCM = doCompanyList(this.companyPageNum,pageSize);
        },

        paperTypePreviousPage:function () {
            if ((this.paperTypePageNum - 1) < 1){
                return;
            }
            this.paperTypePageNum--;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,1);
        },
        paperTypePage:function (page) {
            if (!page){
                return;
            }
            this.paperTypePageNum = page;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,1);
        },
        paperTypeNextPage:function () {
            this.paperTypePageNum++;
            this.paperTypePageInfoCM = doCompanyPaperTypeList(this.paperTypePageNum,pageSize,this.companyId,1);
        }

    }
});

var creditEdit = new Vue({
    el:"#editModal",
    data:{
        paperTypeList:{},
        companyId:"",
        paperTypeId:"",
        type:"",
        relationGrade: 1
    },
    methods:{
        save:function () {
            this.paperTypeId = $("#paperTypeModal").val();
            creditAdd(this.companyId,this.paperTypeId,this.type,this.relationGrade);
            $("#saveModal").attr("data-dismiss", "modal");
        }
    }
});

rateCredit.companyPageInfoCM = doCompanyList(rateCredit.companyPageNum,pageSize);
paymentCredit.companyPageInfoCM = doCompanyList(paymentCredit.companyPageNum,pageSize);
creditEdit.paperTypeList = doPaperTypeList(1,pageSize);