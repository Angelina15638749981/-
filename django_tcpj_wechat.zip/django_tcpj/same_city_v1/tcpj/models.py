from django.db import models

# Create your models here.
import mongoengine
class Chattingcontent(mongoengine.Document):
    # time
    time = mongoengine.StringField(max_length=50, null=True)
    # sender
    sender = mongoengine.StringField(max_length=50, null=True)
    # message from wechat chatting group
    message = mongoengine.StringField(max_length=50, null=True)




