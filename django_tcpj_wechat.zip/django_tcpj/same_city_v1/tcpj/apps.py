from django.apps import AppConfig


class TcpjConfig(AppConfig):
    name = 'tcpj'
