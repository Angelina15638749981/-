from django.conf.urls import url
from . import views
urlpatterns = [
    # url(r'^$', views.info1, name="index"),
    url(r'^wechat/$', views.wechat, name='info'),
    url(r'^info1/$', views.get_info, name='info1')
]