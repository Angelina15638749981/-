import datetime
import json
import time
from functools import reduce
import random

from django.views import View
from mongoengine.queryset.visitor import Q
from django.http import JsonResponse
from django.shortcuts import render, redirect

import numpy as np
# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render, HttpResponse
from django.urls import reverse
from .models import Chattingcontent



def get_info(request):
    result = Chattingcontent.objects.all()
    # print(result)
    for x in result:
        print(x["message"])

    return HttpResponse("Wechat Robot Testing")




f = open(r"/home/ubuntu/Desktop/django_tcpj/chatting_content.txt", "r")
content_lines = f.readlines()
# print(content_lines, type(content_lines))
def wechat(request):
    with open(r"/home/ubuntu/Desktop/django_tcpj/chatting_content.txt", "r") as f:
        content = f.read()
        # while True:
        #     content_line = f.readline()
        #     print(content_line)
        # for content_line in content_lines:

        data = {
            "chatting_content": content
        }
    return render(request, "data.html", context=data)













